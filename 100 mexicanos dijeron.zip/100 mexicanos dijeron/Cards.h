#include<time.h>
#include <iostream>
using namespace std;


//Struct de respuestas que tiene un stringa para cada respuestas y su valor
struct CAnswer{
string answer;
int value;
};

//Clase pregunta que tiene arreglo de 5 struct answer
class CQuest{
    public:
string question;
CAnswer answers[5];

    string getQuestion(){
    return question;
    }
        void setQuestion( string _quest)
    {
        question = _quest;
    }
    void setAnswers(string _ans1, string _ans2 ,string _ans3, string _ans4, string _ans5)
    {
        answers[0].answer   = _ans1;
        answers[1].answer= _ans2;
        answers[2].answer= _ans3;
        answers[3].answer= _ans4;
        answers[4].answer= _ans5;
    }

    void setAnsValue()
    {
        for (int i = 0;i<5;i++)
        {
            answers[i].value =rand()% 3 + 20;
        }
    }


    int checkAnswerValue( string _ans)
    {
        for(int i =0 ;i <5;i++)
        {
            if(answers[i].answer == _ans)
            {
                return answers[i].value;
            }
        }
        return 0;
    }
};




//Clase tema que tiene un arreglo de objetos pregunta
class CTheme{
public:
string theme;
CQuest cSet[5];

void setTheme(string _theme){
    theme =_theme;
}


CQuest getCard(int n)
{
    return  cSet[n];
}



void printQuest(int i)
{
        cout <<  cSet[i].question <<endl;
}

void printAnswer(string answer, int i)
{
    for(int j=0;j<5;j++)
    {
        if(cSet[i].answers[j].answer == answer)
        {
                cout << cSet[i].answers[j].answer <<endl;
        }
    }
}
};



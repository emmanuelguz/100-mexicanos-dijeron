
#include "listas.h"

#include "Cards.h"

//blue = true --- red = false

//Clase jugador
class CPlayer{
private:
    string  name;
    bool capitan;//Solo un jugador de cada equipo tendra como true este valor, indicando que es el capitan
    bool team;
    public:
       void  Player(string _name, bool _team){
            name =_name;
            team = _team;
        }

    void setName(string _name){
        name=_name;
    }

     void setTeam(bool _team){
        team=_team;
    }
    string getName(){
    return name;
    }
    bool getTeam(){
        return team;
    }
    bool getCapt(){
        return capitan;
    }
};
//Clase jugador
class CTeam{
    private:
    int points;
    int fails;

public:
    string  name;
    Node <CPlayer> *TeamLeader;
    void setPoints(int _points){
        points=_points;
        }
    void setFails(int _points){
        points=_points;
        }
    int getPoints(){return points;}
    int getFails(){return fails;}
    string getName(){return name;}


};





//Clase juego
class CGame{

    Node <CTheme> *cards;//Declaracion de lista ligada para guardar todas las cartas con preguntas
      CTeam Team1;
    CTeam Team2;
    CTeam Teamarray[2] = {Team1, Team2};
    //Declaracion de objeto temas de preguntas, esta clase tiene un arreglo con 5 objeto pregunta que a su ves esta clase tiene un arreglo de 5 structs answer
    CTheme Geografia;
    CTheme Television;
    CTheme Historia;
    CTheme General;

    int num_players;
//Funcion para declarar las preguntas y sus respectivas respuestas de cada tema
void createFullSetofCards()
{

    Geografia.setTheme("Geografia");
    Television.setTheme("Television");
    Historia.setTheme("Historia");
    General.setTheme("General");

    Geografia.cSet[0].setQuestion("Capital de Chile ");
    Geografia.cSet[0].setAnswers("Valparaiso","Temuco", "Iquique",  "La Serena","Santiago");

    Geografia.cSet[1].setQuestion("Cuantos paises hay en el mundo");
    Geografia.cSet[1].setAnswers("104","157", "212",  "169","195");

    Geografia.cSet[2].setQuestion("Cuantos oceanos hay en en la tierra");
    Geografia.cSet[2].setAnswers("11","5", "6",  "3","4");

    Geografia.cSet[3].setQuestion("Segundo pais mas grande  del Mundo");
    Geografia.cSet[3].setAnswers("China","Rusia", "India",  "Estados Unidos","Japon");

    Geografia.cSet[4].setQuestion("Ciudad mas poblada del mundo");
    Geografia.cSet[4].setAnswers("Shangai","Rio de Janeiro", "DF",  "Moscu","Nueva York");



    Television.cSet[0].setQuestion("Identidad del compayito");
    Television.cSet[0].setAnswers("Loret de Mola","Perro Bermudes", "Christian Martinoli",  "Luis Garcia","Edson Zu�iga");

    Television.cSet[1].setQuestion("Telenovelas mas famosas");
    Television.cSet[1].setAnswers("Amores verdaderos","Betty la fea", "Fuego en la sangre",  "Hasta que el dinero nos separe","Juan Querendon");

    Television.cSet[2].setQuestion("Series  mexicanas");
    Television.cSet[2].setAnswers("Vecinos","La familia P. Luche", "La CQ",  "El Chavo del 8","Rebelde");

    Television.cSet[3].setQuestion("Famosos actores  mexicanos");
    Television.cSet[3].setAnswers("Eugenio Derbez","Roberto Gomez Bolanos", "Diego Luna",  "Salma Hayek","Maribel Guardia");

    Television.cSet[4].setQuestion("Hosts de Hoy");
    Television.cSet[4].setAnswers("Galilea Montijo","Andrea Legarreta", "Raul Araiza",  "Juan Jose Origel","Yanet Garcia");




    Historia.cSet[0].setQuestion("Antiguos presidentes de Mexico");
    Historia.cSet[0].setAnswers("Benito Juarez","Guadalupe Victoria", "Porfirio Diaz",  "Francisco I.  Madero","Venustiano Carranza");

    Historia.cSet[1].setQuestion("Eventos importantes mexicanos");
    Historia.cSet[1].setAnswers("Independencia","Revolucion", "Batalla de puebla",  "Noche triste","Expropiacion petrolera");

    Historia.cSet[2].setQuestion("Paises contra los que peleo Mexico a lo largo de su historia");
    Historia.cSet[2].setAnswers("Espa�a","Estados Unidos", "Francia",  "Venezuela","el Eje");

    Historia.cSet[3].setQuestion("Peores desastres naturales en Mexico");
    Historia.cSet[3].setAnswers("Erupcion del Parcut�n","Huracan de 1959", " Terremoto de 1985",  "Inundaciones en tabasco","Terremoto 2017");

    Historia.cSet[4].setQuestion("Aliados de Mexico");
    Historia.cSet[4].setAnswers("Estados Unidos","Venezuela", "Chile",  "Haiti","Canada");



    General.cSet[0].setQuestion("Cosas con las que te puedes resbalar");
    General.cSet[0].setAnswers("Agua","Cascara de platano", "Jabon",  "Aceite","Lodo");

    General.cSet[1].setQuestion("Cosas que te ensa�an a usar en un avion");
    General.cSet[1].setAnswers("Macarilla de oxigeno","Cinturon de seguridad", "Chaleco salvavidas",  "Bolsa de mareo","Juan Querendon");

    General.cSet[2].setQuestion("Pariente politico con el que te fuerzan a llevarte bien");
    General.cSet[2].setAnswers("Suegros","Cu�ados", "Yerno",  "Nuera","Cu�ado");

    General.cSet[3].setQuestion("Donde mas sale pelo ademas de la cabeza");
    General.cSet[3].setAnswers("Pecho","Axila", " Cara",  "Piernas","Panza");

    General.cSet[4].setQuestion("Que animales usan los magos en sus shows");
    General.cSet[4].setAnswers("Conejo","Palomas", "Elefantes",  "Tigres","Ratones");


    cards = new Node<CTheme>(Geografia);
    PushBack<CTheme>(cards,Historia);
    PushBack<CTheme>(cards,Television);
    PushBack<CTheme>(cards,General);
}

//Funcion que crea los equipos dependiendo del numero de jugadores y setea sus nombre
void setTeams()
{
    cout<<"Introduce numero de jugadores por equipo"<<endl;
    cin>>num_players;

    cout<<"Introduce nombre equipo 1"<<endl;
    cin >>Team1.name;

    cout<<"Introduce nombre equipo 2"<<endl;
    cin >> Team2.name;

    cout<<"Introduce nombre de jugadores del equipo 1, el primero sera el lider"<<endl;
    for(int i=0;i<num_players*2;i++)
    {
        if(i < num_players)
        {
          //  CPlayer player = new Node<CPlayer>();
            //PushBack<CPlayer>(Team1.TeamLeader,)
        }
        else{

        }
    }
}

void SelectTheme()
{
    //cout<<"Le toca sleccionar tema al equipo";
    cout<<"Seleccione uno de estos temas";

}
void Round(int j)
{
    for(int i = 0; i < num_players; i++)
    {

    }
}

};




int main()
{
srand(time(NULL));
CGame game1;




    return 0;
}

#include "Cards.h"
#include <string>


//Clase stack
class CardStack{
    private:
    CQuest *head;
    int top;

    public:
        //Construcor
    CardStack(){
        head = NULL;
        top= -1;
    }

    //PushBack de preguntas
    void PushBackQuest( string _quest, string _theme){
        CQuest *temp;
        CQuest *newNode = new CQuest(_quest, _theme);
        if(top == -1)
        {
            newNode->next = head;
            head= newNode;
            top++;
        return;
        }
        temp = head;
        while(temp->next !=NULL){
                temp = temp->next;
        }
        temp->next = newNode;
        top++;
        return;
    }

    CQuest* getCard(int n){
         if(n > top || n < 0) {
            std::cout << "La posicion no existe dentro del stack";
        }
        int ite=0;
        CQuest *temp = head;

        while(ite != n){
             temp = temp->next;
            ite++;
        }
        return temp;
    }

    //Imprime pregunta en posicion n del stack
    void printQuest(int n){
        CQuest *temp = getCard(n);
        std::cout << temp->getQuestion();
    }

    //Imprime themas existentes  en stack
    void printThemes(){
        CQuest *temp = head;
        string last = "";
        int ite=1;
        while(temp != NULL){
            if( last != temp->getTheme())
            {
                last = temp->getTheme();
                cout<<ite<<": "<<last<<endl;
                ite++;
            }
            temp = temp->next;
        }
    }


    //Busca en stack pregunta en posicion n y guarda las respuestas
    void MakeAns(int i, string _ans1, string _ans2 ,string _ans3, string _ans4, string _ans5){
        CQuest *temp = getCard(i);
        temp->setAnswers(_ans1, _ans2 , _ans3,  _ans4, _ans5);
        temp->setAnsValue();

    }


    bool CorrectAnswer(int n, string _ans)
    {
        CQuest *temp = getCard(n);
        if(temp->checkAnswer(_ans))
        {
           cout<<_ans<<"----------------------------------------------------------------------------------> "<<temp->checkAnswerValue(_ans)<<endl;
            return true;
        }
        else{
            return false;
        }

    }
    void PrintUnusedAnswer(int n)
    {
        CQuest *temp = getCard(n);
        temp->PrintRestAns();
    }


    int getAnswerPoints(int n,string _ans){
        CQuest *temp = getCard(n);
        if(temp->checkAnswer(_ans))
        {
            int val = temp->checkAnswerValue(_ans);
            cout<<val<<endl;
            return val;
        }
        else{

        }
    }
};

CardStack createFullSetofCards()
{
    srand(time(NULL));
     string questions[20];
     string answers[20];


    questions[0] ="Capital de Chile ";
    questions[1] ="Cuantos paises hay en el mundo";
    questions[2]="Cuantos oceanos hay en en la tierra";
    questions[3] ="Segundo pais mas grande  del Mundo";
    questions[4] ="Ciudad mas poblada del mundo";
    questions[5] ="Identidad del compayito";
    questions[6] ="Telenovelas mas famosas";
    questions[7] ="Series  mexicanas";
    questions[8] ="Famosos actores  mexicanos";
    questions[9] ="Hosts de Hoy";
    questions[10] ="Antiguos presidentes de Mexico";
    questions[11] ="Eventos importantes mexicanos";
    questions[12] ="Paises contra los que peleo Mexico a lo largo de su historia";
    questions[13] ="Peores desastres naturales en Mexico";
    questions[14] ="Aliados de Mexico";
    questions[15] ="Cosas con las que te puedes resbalar";
    questions[16] ="Cosas que te ensa�an a usar en un avion";
    questions[17] ="Pariente politico con el que te fuerzan a llevarte bien";
    questions[18] ="Donde mas sale pelo ademas de la cabeza";
    questions[19] ="Que animales usan los magos en sus shows";

    CardStack allCards;
    for (int i=0;i<20;i++){
        if(i<5){
        allCards.PushBackQuest(questions[i],"Geografia");

        }
        if(i>4 && i<10){
            allCards.PushBackQuest(questions[i],"Television");

        }
        if(i>9 &&i<15){
            allCards.PushBackQuest(questions[i],"Historia");

        }
        if( i>14 &&i<20){
            allCards.PushBackQuest(questions[i],"General");

        }

    }
    allCards.MakeAns(0,"Valparaiso","Temuco", "Iquique",  "Concepcion","Santiago");
    allCards.MakeAns(1,"104","157", "212",  "169","195");
    allCards.MakeAns(2,"11","5", "6",  "3","4");
    allCards.MakeAns(3,"China","Rusia", "India",  "Estados Unidos","Japon");
    allCards.MakeAns(4,"Shangai","Washington", "DF",  "Moscu"," Tokio");
    allCards.MakeAns(5,"Loret de Mola","Perro Bermudes", "Christian Martinoli",  "Luis Garcia","Edson Zu�iga");
    allCards.MakeAns(6,"Amores verdaderos","Betty la fea", "Fuego en la sangre",  "Hasta que el dinero nos separe","Juan Querendon");
    allCards.MakeAns(7,"Vecinos","La familia P. Luche", "La CQ",  "El Chavo del 8","Rebelde");
    allCards.MakeAns(8,"Eugenio Derbez","Roberto Gomez Bolanos", "Diego Luna",  "Salma Hayek","Maribel Guardia");
    allCards.MakeAns(9,"Galilea Montijo","Andrea Legarreta", "Raul Araiza",  "Juan Jose Origel","Yanet Garcia");
    allCards.MakeAns(10,"Benito Juarez","Guadalupe Victoria", "Porfirio Diaz",  "Francisco I.  Madero","Venustiano Carranza");
    allCards.MakeAns(11,"Independencia","Revolucion", "Batalla de puebla",  "Noche triste","Expropiacion petrolera");
    allCards.MakeAns(12,"Espa�a","Estados Unidos", "Francia",  "Venezuela","el Eje");
    allCards.MakeAns(13,"Erupcion del Parcut�n","Huracan de 1959", " Terremoto de 1985",  "Inundaciones en tabasco","Terremoto 2017");
    allCards.MakeAns(14,"Estados Unidos","Venezuela", "Chile",  "Haiti","Canada");
    allCards.MakeAns(15,"Agua","Cascara de platano", "Jabon",  "Aceite","Lodo");
    allCards.MakeAns(16,"Macarilla de oxigeno","Cinturon de seguridad", "Chaleco salvavidas",  "Bolsa de mareo","Juan Querendon");
    allCards.MakeAns(17,"Suegros","Cu�ados", "Yerno",  "Nuera","Cu�ado");
    allCards.MakeAns(18,"Pecho","Axila", " Cara",  "Piernas","Panza");
    allCards.MakeAns(19,"Conejo","Palomas", "Elefantes",  "Tigres","Ratones");




    return allCards;
}





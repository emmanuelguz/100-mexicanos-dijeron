#include <iostream>
#include <string>
using namespace std;


//Struct de respuestas que tiene un stringa para cada respuestas y su valor
struct CAnswer{
string answer;
int value=0;
bool used = false;
};

//Clase pregunta que tiene arreglo de 5 struct answer
class CQuest{
private:
    string question;
    string theme;
    CAnswer answers[5];


    public:
    CQuest *next;
    CQuest( string _quest,string _theme){
        question = _quest;
        theme = _theme;
    }

    bool CheckIfUsed(int i)
    {
        return answers[i].used;
    }

    string getQuestion(){
    return question;
    }
        void setQuestion( string _quest)
    {
        question = _quest;
    }

    void setTheme(string _theme){

        theme =_theme;
    }
    string getTheme(){
        return theme;
    }
    //Guarda respuesptas de arreglo
    void setAnswers(string _ans1, string _ans2 ,string _ans3, string _ans4, string _ans5)
    {
        answers[0].answer   = _ans1;
        answers[1].answer= _ans2;
        answers[2].answer= _ans3;
        answers[3].answer= _ans4;
        answers[4].answer= _ans5;
    }

    //Pone valor respuesptas de arreglo
    void setAnsValue()
    {
        for (int i = 0;i<5;i++)
        {
            answers[i].value =rand()% 20 + 3;
        }
    }
    bool CheckIfAllUsed(){
        int ansUsed=0;
        for(int i=0; i<5; i++){
            if(CheckIfUsed(i))
            {
                ansUsed++;
            }
        }
        if(ansUsed == 4){
            return true;
        }
        else{
            return false;
        }
    }
//compara input de usuario con respuestas en arreglo
    bool checkAnswer( string _ans)
    {
        for(int i =0 ;i <5;i++)
        {
            if(answers[i].answer == _ans &&  answers[i].used ==false)
            {
                answers[i].used =true;
                return true;
            }

        }
        return false;
    }



//Checa valor de respuesta del arreglo
    int checkAnswerValue( string _ans)
    {
        for(int i =0 ;i <5;i++)
        {
            if(answers[i].answer == _ans)
            {
                return answers[i].value;
            }
        }
        return 0;
    }

    void PrintRestAns()
    {
        for(int i =0 ;i <5;i++)
        {
                if(!answers[i].used)
            {
                cout<<answers[i].answer<<"----------------------------------------------------------------------------------> "<<answers[i].value<<endl;
            }
        }
    }


};



#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <string>
using namespace std;


struct PlayerNode{
      string  name;
    bool capitan;//Solo un jugador de cada equipo tendra como true este valor, indicando que es el capitan
    bool team;
    PlayerNode *nextPlayer;

    PlayerNode(string _name, bool  cptn){
            this->name =_name;
            this->capitan = cptn;
            this->nextPlayer = NULL;
        }
    PlayerNode(){
        this->name ="";
            this->capitan = false;
            this->nextPlayer = NULL;
    }

};


class CTeam{
private:
     int points=0;
    int teamSize;
    string  name;
    PlayerNode *Capi;

public:
    int fails=0;
    void setTeamSize( int _s){
            teamSize = _s;
        }
    void setPoints(int _points){
            points+=_points;
            }
    void setName(){
        getline(cin,name);
        //cin>>name;
        }
    int getPoints(){return points;}

    string getName(){return name;}

    void setPlayer(PlayerNode *root){
        PlayerNode *aux;
        PlayerNode *newPlayer ;
        aux=root;

        while(aux->nextPlayer != NULL){
            aux = aux->nextPlayer;
        }
            string playName;
            getline(cin,playName);
            newPlayer = new PlayerNode(playName,false);
            aux->nextPlayer = newPlayer;
            return ;
    }

    void setTeam(int num){
        string capiName;
        setTeamSize(num);
        cout<<"Introduce nombre del capitan  del equipo "<<name<<endl;
        getline(cin,capiName);
        Capi = new PlayerNode(capiName,true);
        for (int i = 1; i<num; i++)
        {
            cout<<"Introduce nombre del integrante "<< i+1<<endl;
            setPlayer(Capi);
        }
    }


    void PrintTeamList(){
        cout<<"Los integrantes del equipo "<<name<<" son: " <<endl;
        PlayerNode *aux;
        aux = Capi;
        cout<<aux->name <<endl;
        while(aux->nextPlayer != NULL){
            aux = aux->nextPlayer;
            cout<<aux->name <<endl;
        }
        return;
    }
    PlayerNode* getPlayer(int n){
         if(n > teamSize || n < 0) {
            cout << "La posicion no existe";
        }
        int ite=0;
        PlayerNode *temp = Capi;

        while(ite != n){
             temp = temp->nextPlayer;
            ite++;
        }
        return temp;
    }
    string PlayerName(int n)
    {
        PlayerNode *temp = getPlayer(n);
        return temp->name;
    }
};


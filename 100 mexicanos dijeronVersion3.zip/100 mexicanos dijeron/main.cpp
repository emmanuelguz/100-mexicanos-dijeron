#include "Players.h"
#include "CardStack.h"
#include <time.h>
#include <limits>
#include <string>

//Funcion para declarar las preguntas y sus respectivas respuestas de cada tema

string failsX[3] = {"X","XX","XXX"};
bool checkValueType(int val)
{
    int cont=0;
    while(!(cin >> val)){
            cout << "Valor invalido pruebe otra vez: ";
            cont++;
            val =0;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            if(cont >5)
            {
            system("cls");
             cont=0;
             cout << "Valor invalido pruebe otra vez: ";
            }
        }
    return true;
}
//Clase juego
class CGame{
public:
    CTeam Teamarray[2] ;
    int teamIte=0; //Iterador de equipos
    int numRounds =4;
    int teamSize;
    CardStack stackCartas = createFullSetofCards();

//Funcion que crea los equipos dependiendo del numero de jugadores y setea sus nombre
void setTeams()
{
        cout <<"Introduce el tamanio de los equipos: "<<endl;
        cin>>teamSize;
        cin.ignore();

        cout <<"Introduce nombre del equipo 1"<<endl;
        Teamarray[0].setName();
        Teamarray[0].setTeam(teamSize);

        cout <<"Introduce nombre del equipo 2"<<endl;
        Teamarray[1].setName();
        Teamarray[1].setTeam(teamSize);


            system("cls");
            Teamarray[0].PrintTeamList();
            Teamarray[1].PrintTeamList();

}

void ChooseFirst(){
    cout <<"Que equipo ira primero? "<<endl;
        cout <<"1: "<< Teamarray[0].getName()<<"  o  "<<"2: "<<Teamarray[1].getName()<<endl;
        cin>>teamIte;
        cin.ignore();
            if( teamIte == 1 || teamIte== 2 ){
                teamIte--;
                return;
            }
            else{
                cout <<"Ese equipo no existe "<<endl;
                return;
            }
}

int SelectTheme()
{
    int selcetorT;//Seleccionador de tema
    int selcetorQ;//Seleccionador de pregunta

        cout<<"Seleccione uno de estos temas"<<endl;
        stackCartas.printThemes();
        cin>>selcetorT;
        cin.ignore();
        switch(selcetorT)
        {
        case 1:
            selcetorQ = rand() % 5; //Numero random de 0 a 4
            break;
        case 2:
            selcetorQ = rand() % 5 + 5; //Numero random de 5 a 9
            break;
        case 3:
            selcetorQ = rand() % 5 + 10; //Numero random de 10 a 14
            break;
        case 4:
            selcetorQ = rand() % 5 + 15; //Numero random de 15 a 19
            break;
        }
        return selcetorQ;
}

void Round(int idQuest)
{
    string answer;
    int roundPoints=0;
    int i=0;//Iterador de players en equipo

    //Crea auxiliar con informacion de carta
            CQuest *aux = stackCartas.getCard(idQuest);



         cout<<"Turno del equipo "<<Teamarray[teamIte].getName()<< ": "<<endl<<endl;
         stackCartas.printQuest(idQuest);cout<<endl<<endl;

         //Checa que no se hayan dado todas las respuestas
         while(!aux->CheckIfAllUsed())
         {
            cout<<"La respuesta de "<<Teamarray[teamIte].PlayerName(i)<< " es: ";
            getline(cin,answer);


            //Checa si respuesta dada es incorrecta
             if(!stackCartas.CorrectAnswer(idQuest,answer)){
                    Teamarray[teamIte].fails++; //aumenta numero de fallos al equipo
                    cout<<failsX[Teamarray[teamIte].fails-1]<<endl;
                    i++;
                    //Reinicia iterador de players una vez se haya llegado al ultimo
                    if(i==teamSize){
                        i=0;
                    }
                    //Si el equipo llega a tres fallos se cambia de equipo para robo de puntos
                    if( Teamarray[teamIte].fails == 3){
                            if(teamIte==1){teamIte--;}else{teamIte++; i=0;}
                                cout<<"Turno del "<<Teamarray[teamIte].getName()<< " para el robo de puntos!!"<<endl;
                                cout<<"La respuesta de "<<Teamarray[teamIte].PlayerName(i)<< " es: ";
                                getline(cin,answer);
                             if(!stackCartas.CorrectAnswer(idQuest,answer)){
                                      if(teamIte==1){teamIte--;}else{teamIte++; i=0;}
                                      Teamarray[teamIte].setPoints(roundPoints);
                                      cout<<"El equipo "<<Teamarray[teamIte].getName()<< " se queda con los puntos!!"<<endl;

                                      cout<<"El marcador va:\n "<<Teamarray[teamIte].getName()<<"con: "<<Teamarray[teamIte].getPoints()<< " puntos"<<endl;
                                      if(teamIte==1){teamIte--;}else{teamIte++; i=0;}
                                      cout<<Teamarray[teamIte].getName()<<"con: "<<Teamarray[teamIte].getPoints()<< " puntos"<<endl;
                                      return;
                             }
                         else{
                             if(teamIte==1){teamIte--;}else{teamIte++; i=0;}
                                cout<<"El equipo "<<Teamarray[teamIte].getName()<< " se roba los puntos!!"<<endl;
                                roundPoints+= aux->checkAnswerValue(answer);
                                Teamarray[teamIte].setPoints(roundPoints);

                               cout<<"El marcador va:\n "<<Teamarray[teamIte].getName()<<"con: "<<Teamarray[teamIte].getPoints()<< " puntos"<<endl;
                              if(teamIte==1){teamIte--;}else{teamIte++; i=0;}
                              cout<<Teamarray[teamIte].getName()<<"con: "<<Teamarray[teamIte].getPoints()<< " puntos"<<endl;
                              cout<<"El resto de las respuestas son"<<endl;
                              aux->PrintRestAns();
                              return;
                         }
                    }
             }
             else{
                    i++;
                     if(i==teamSize){
                        i=0;
                    }
                roundPoints+= aux->checkAnswerValue(answer);
             cout<<"Puntos de ronda: "<<roundPoints<<endl;
             }
         }
           cout<<"El equipo "<<Teamarray[teamIte].getName()<< " se queda con los puntos!!"<<endl;
            Teamarray[teamIte].setPoints(roundPoints);
             cout<<"El marcador va:\n "<<Teamarray[teamIte].getName()<<"con: "<<Teamarray[teamIte].getPoints()<< " puntos"<<endl;
            if(teamIte==1){teamIte--;}else{teamIte++; i=0;}
            cout<<Teamarray[teamIte].getName()<<"con: "<<Teamarray[teamIte].getPoints()<< " puntos"<<endl;

}

void FullGame(){
    srand(time(NULL));
    int sel;
    cout<<"Introduzca numero de rondas"<<endl;
    cin >>numRounds;
    cin.ignore();
    for(int i = 0; i<numRounds;i++){
            //system("cls");
            cout<<"Para la ronda quieren seleccionar un tema = 1 o un tema aleatorio = 2"<<endl;
            cin>>sel;
            cin.ignore();
            if(sel==1)
            {
                ChooseFirst();
                Round(SelectTheme());

            }else{
                int aux = rand()%20;
                ChooseFirst();
                Round(aux);
            }
    }
//system("cls");
    cout<<"/////////////////////////////////////////////////"<<endl;
    cout<<"//////////////////FIN DEL JUEGO//////////////////"<<endl;
    cout<<"/////////////////////////////////////////////////"<<endl;
    cout<<"////////////////////GANADORES////////////////////"<<endl;
    cout<<"/////////////////////////////////////////////////"<<endl;
    if(Teamarray[0].getPoints() > Teamarray[1].getPoints())
    {
        cout<<"                         "<<Teamarray[0].getName()<<endl;
    }
    else{
        cout<<Teamarray[1].getName()<<endl;
    }

}

};




int main()
{
srand(time(NULL));
    CGame game1;
    game1.setTeams();
    game1.FullGame();

    return 0;
}


